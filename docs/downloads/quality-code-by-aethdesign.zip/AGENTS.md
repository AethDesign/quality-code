<!-- quality-code:start -->
## Shared quality foundation

Apply the selected standards once. Preserve project-specific instructions, user decisions, existing work and stricter risk, permission and verification requirements. Omitting a module never waives an existing project requirement. Set observable acceptance criteria before implementation. Distinguish evidence-backed defects from preferences and report uncertainty.

Verify the changed product behavior and disclose unavailable evidence. A build, score, screenshot, helper completion or generated audit packet is not an independent verdict. A builder or material implementation director cannot supply a required independent audit verdict. Resolve blocking findings and obtain the required re-review before claiming completion; unavailable required evidence remains BLOCKED. Never invent test results, legal claims, integrations, credentials, client relationships or savings.

For review, diagnosis, or planning, inspect and report without implementing. Ask before destructive actions, external writes, releases, purchases, or material scope expansion unless already authorized.

### Secret-access boundary

Never read or otherwise interact with protected files or folders unless the user explicitly authorizes the relevant path or clearly scoped sensitive category and operation. Protected names include `.env`, `.env.*`, `*.env` (including examples/templates), secret or credential files, private keys and credential stores, and project folders labelled `secret`, `secrets`, `credentials`, `sensitive`, `private` or `scr`, including equivalent names and case variants. Ordinary `src` source directories are not `scr`; platform paths such as macOS `/private/tmp` are not project secret labels. Treat a known sensitive target as protected regardless of its name.

This prohibition includes content searches, opening, sourcing/loading, execution, modification, creation, copying, moving, deletion, hashing, archiving, uploading and access through symlinks, helpers or integrations. Minimal pathname metadata needed to recognize and exclude protected paths is allowed; do not inspect contents to decide whether they are secret. Before recursive searches or running commands, scripts, tests or tools, establish that their scope excludes protected paths and indirect access. Ignore rules alone do not establish safety. If that cannot be established, stop the dependent operation and request specific permission; continue safe independent work. General instructions to build, debug, audit or deploy, repository access and a required verification gate are not secret-access permission.

Honor existing explicit authorization within its scope; do not ask again for the same authorized operation. Access only what is necessary. Using an already-authenticated tool without retrieving secret values is permitted; it grants no permission to inspect credential stores or load protected project files. Permission to use a credential does not permit displaying or publishing it: keep secret values out of chat, tool output, logs, commits and artifacts. Never bypass this boundary with another tool or agent. Unavailable protected evidence remains BLOCKED, not a presumed pass.

## Quality Code by AethDesign

## Quality-code workflow

For any change affecting code, configuration, dependencies, tests, builds, data, releases, or agent behavior:

1. Read only the `MAP.md` sections relevant to touched files.
2. State observable acceptance criteria before implementation.
3. Replace bootstrap gaps in `MAP.md` and `TESTING.md`; ensure `.quality/quality.toml` profiles run the project's real tests and checks. `git diff --check` alone is not behavioral evidence.
4. Classify the highest actual product risk. An explicit higher-risk route in `.quality/quality.toml` cannot be downgraded. A routine local build, install, or version bump used only to deliver or confirm a change inherits the underlying change's risk.
5. **Low — builder only:** isolated copy, label, display text, comments, formatting, or static style with no behavior, data, accessibility, localization-contract, legal, billing, security, build, release, or agent-instruction effect. Make the smallest change and perform one focused visual, static, or targeted confirmation. Do not run the full suite, generate an audit packet, or start a subagent unless the user explicitly requests it or evidence raises the risk.
6. **Normal — contained behavior:** use proportionate test/fix loops, add or update the smallest relevant regression test, and run the smallest changed-scope verification that covers the behavior. Do not request an independent audit by default; do so only when the user asks or unresolved uncertainty raises the risk to high.
7. **High or critical — independent gate:** run the required higher verification profiles, generate `./quality audit-packet --criteria "<criteria>"`, and start a fresh agent with the audit skill (`$audit-code-change` in Codex or `/audit-code-change` in Claude Code). Once started, the audit remains exhaustive within scope.
8. Builder validation is mandatory in every lane. For a concrete bug, field-test the original or smallest failing case only as needed to understand it, then once to confirm the fix. Add more cases only when requested or justified by risk, an unclear cause, or inconsistent results.
9. Resolve blocking audit findings and request re-audit when an independent audit was required. Otherwise hand off after the lane's evidence passes, with residual risk stated when material.

### Git ownership and history

Use Git for coding work. Before editing, confirm the intended repository root, base commit, task branch and owned outcome. Initialize Git for a new standalone project. Give each concurrent writer a dedicated worktree or clone and short-lived task branch. Honor project conventions and the secret-access boundary when checking out files. Record shared contract dependencies and their owner before parallel implementation.

Leave unrelated staged, unstaged and untracked work with its owner. In a mixed checkout, transfer only edits you can identify as yours into your task checkout. Coordinate ambiguous or overlapping hunks before proceeding. Never stash, reset, clean or stage another writer’s changes to finish your task.

Stage explicit owned changes, inspect the complete staged path list and permitted patch, run applicable checks and commit coherent outcomes with related tests and a descriptive subject. At handoff give the branch, commit SHA, verification and dependencies, or the reason a commit is blocked. Bind any required independent review to the task’s base and exact candidate commit. Recheck affected contracts on integration. Follow repository authorization for pushing, merging and releases.
<!-- quality-code:end -->
